// lib/admitlyCors.ts
//
// The Chrome extension and web app call these routes cross-origin, so we
// need explicit CORS headers. Replace ALLOWED_ORIGINS with your real values
// once you have the extension's actual ID (shown in chrome://extensions
// after you load it unpacked) and your web app's real domain.

export const ALLOWED_ORIGINS = [
  'https://admitly-woad.vercel.app',
  'chrome-extension://REPLACE_WITH_YOUR_EXTENSION_ID',
];

export function corsHeaders(origin: string | null) {
  const allowed = origin && ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': allowed,
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  };
}
